import data from './LibraryList';

export default () => data;
